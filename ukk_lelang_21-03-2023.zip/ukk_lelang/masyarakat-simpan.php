<?php 
  session_start();
  include "koneksi.php";

  // Cek tersediaan username ditabel masyarakat
  $username = htmlspecialchars($_POST['username2']);
  $sql = "SELECT * FROM tbl_login WHERE username = '$username' ORDER BY username";
  $query = mysqli_query($koneksi, $sql);
  if(mysqli_num_rows($query)>0){
    $_SESSION['info'] = 'Gagal Disimpan';
  }else{

    // Cek tersediaan username ditabel mpetugas
    $sql1 = "SELECT * FROM petugas WHERE username = '$username' ORDER BY username";
    $query1 = mysqli_query($koneksi, $sql1);
    if(mysqli_num_rows($query1)>0){
      $_SESSION['info'] = 'Gagal Disimpan';
    }else{

      $nama_lengkap = $_POST['nama_lengkap'];
      $password     = $_POST['password2'];
      $telp         = $_POST['telp'];
  
      $sql = "INSERT INTO masyarakat(nama_lengkap, username, password, telp) VALUES('$nama_lengkap', '$username', '$password', '$telp')";
      mysqli_query($koneksi, $sql);
      
      $sql2   = "SELECT * FROM masyarakat ORDER BY id_user DESC";
      $query2 = mysqli_query($koneksi, $sql2);
      $data2  = mysqli_fetch_array($query2);
      
      $_SESSION['id_login']     = "sudahLogin";
      $_SESSION['id_petugas']   = $data2['id_user'];
      $_SESSION['nama_petugas'] = $nama_lengkap;
      $_SESSION['id_user']      = $data2['id_user'];
      $_SESSION['nama_lengkap'] = $nama_lengkap;
      $_SESSION['level']        = 3;
      
    }
  }
  header("location:index.php");

?>