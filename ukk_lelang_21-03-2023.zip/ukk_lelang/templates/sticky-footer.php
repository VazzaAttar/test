</div>

<footer style="height: 50px; background: rgb(100, 149, 237);">
	<div class="container">
		<div class="copyright text-center pt-3" style="color: black; font-weight: bold">
			<span>Copyright &copy; Buruan Ngoding <?= date('Y');  ?></span>
		</div>
	</div>
</footer>

</div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
